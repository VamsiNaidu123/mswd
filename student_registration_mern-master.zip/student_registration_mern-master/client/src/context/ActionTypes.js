export const STUDENTS_GET = "STUDENTS_GET";
export const STUDENT_GET = "STUDENT_GET";
export const STUDENT_ADD = "STUDENT_ADD";
export const STUDENT_EDIT = "STUDENT_EDIT";
export const STUDENT_DELETE = "STUDENT_DELETE";
export const STUDENT_ERROR = "STUDENT_ERROR";

export const MAJORS_GET = "MAJORS_GET";
export const MAJOR_ADD = "MAJOR_ADD";
export const MAJOR_EDIT = "MAJOR_EDIT";
export const MAJOR_DELETE = "MAJOR_DELETE";
export const MAJOR_ERROR = "MAJOR_ERROR";
